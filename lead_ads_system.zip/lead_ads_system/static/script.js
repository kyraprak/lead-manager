const form = document.getElementById("leadForm");
const tableBody = document.querySelector("#leadsTable tbody");

// function to fetch and display leads
async function loadLeads() {
    const response = await fetch("/leads");
    const leads = await response.json();
    tableBody.innerHTML = "";
    leads.forEach(lead => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${lead.id}</td>
            <td>${lead.name}</td>
            <td>${lead.email}</td>
            <td>${lead.company}</td>
        `;
        row.style.opacity = 0;
        tableBody.appendChild(row);
        setTimeout(() => {
            row.style.transition = "opacity 0.5s ease";
            row.style.opacity = 1;
        }, 50);
    });
}

// add new lead
form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    await fetch("/add_lead", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    });
    form.reset();
    loadLeads();
});

// initial load
loadLeads();

