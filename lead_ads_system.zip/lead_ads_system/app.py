from flask import Flask, request, jsonify, render_template
import sqlite3
import os
import re

app = Flask(__name__)

DB_NAME = "database.db"

def get_db_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS leads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            company TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/add_lead", methods=["POST"])
def add_lead():
    data = request.json

    if not data:
        return jsonify({"error": "No data provided"}), 400

    name = data.get("name", "").strip()
    email = data.get("email", "").strip()
    company = data.get("company", "").strip()

    if not name or not email or not company:
        return jsonify({"error": "All fields are required"}), 400

    email_pattern = r"^[^@\s]+@[^@\s]+\.[^@\s]+$"
    if not re.match(email_pattern, email):
        return jsonify({"error": "Invalid email format"}), 400

    try:
        conn = get_db_connection()
        conn.execute(
            "INSERT INTO leads (name, email, company) VALUES (?, ?, ?)",
            (name, email, company)
        )
        conn.commit()
        conn.close()
    except Exception:
        return jsonify({"error": "Database error"}), 500

    return jsonify({"message": "Lead added successfully"}), 201

@app.route("/leads", methods=["GET"])
def get_leads():
    conn = get_db_connection()
    leads = conn.execute("SELECT * FROM leads").fetchall()
    conn.close()
    return jsonify([dict(lead) for lead in leads])

if __name__ == "__main__":
    init_db()
    app.run(debug=True)

# Flask application that initializes its own relational schema, persists lead data in SQLite
# and exposes rest endpoints for ingestion and retrieval.”
# http://127.0.0.1:5000/